document.addEventListener("DOMContentLoaded", function() {
    document.getElementById("addProductBtn").addEventListener("click", function() {
        
        let productName = document.getElementById("productName").value;
        let productPrice = document.getElementById("productPrice").value;
        let productImage = document.getElementById("productImage").value;
        let productCategory = document.getElementById("productCategory").value;
        
        
        let newRow = document.createElement("tr");
        newRow.innerHTML = "<td>" + productName + "</td><td>" + productPrice + "</td><td><img src='" + productImage + "' style='max-width:100px; max-height:100px;'></td><td>" + productCategory + "</td>";
        
        document.getElementById("productList").appendChild(newRow);
        
        document.getElementById("productName").value = "";
        document.getElementById("productPrice").value = "";
        document.getElementById("productImage").value = "";
       
        
    });
});